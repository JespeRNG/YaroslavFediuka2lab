function shw_calls(){
	document.getElementById('header').innerHTML="Schedule of calls";
	document.getElementById('img').src="./calls.jpg";
}

function shw_lessons(){
	document.getElementById('header').innerHTML="Schedule of lessons";
	document.getElementById('img').src="./lessons.jpg";
}